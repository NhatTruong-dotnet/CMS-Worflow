﻿// See https://aka.ms/new-console-template for more information
using RabbitMQ.Client;
using System.Text;

Console.WriteLine("Hello, World!");

IConnection conn;
IModel channel;

ConnectionFactory factory = new ConnectionFactory();  
    factory.HostName = "localhost";
    factory.VirtualHost = "/";
    factory.Port = 5672;
    factory.UserName = "guest";
    factory.Password = "guest";
    conn = factory.CreateConnection();

channel = conn.CreateModel();
channel.ExchangeDeclare(
    exchange: "ex.Fanout",
    type: "fanout"
);

channel.QueueDeclare(
    queue: "my.queue1",
    durable:true,
    exclusive:false,
    autoDelete:false,
    arguments:null
    );
channel.QueueDeclare(
    queue: "my.queue2",
    durable: true,
    exclusive: false,
    autoDelete: false,
    arguments: null
    );

channel.QueueBind(queue: "my.queue1", exchange: "ex.Fanout", routingKey:"");
channel.QueueBind(queue: "my.queue2", exchange: "ex.Fanout", routingKey:"");

channel.BasicPublish(
    exchange: "ex.Fanout",
    routingKey: "",
    basicProperties: null,
    body: Encoding.UTF8.GetBytes("Message 1")
);

channel.BasicPublish(
    exchange: "ex.Fanout",
    routingKey: "",
    basicProperties: null,
    body: Encoding.UTF8.GetBytes("Message 2")
);

channel.QueueDelete("my.queue1");
channel.QueueDelete("my.queue2");
channel.ExchangeDelete("ex.Fanout");

channel.Close();
conn.Close();
Console.ReadLine();
