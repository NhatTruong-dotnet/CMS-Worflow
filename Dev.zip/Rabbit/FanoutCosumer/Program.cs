﻿// See https://aka.ms/new-console-template for more information
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Runtime.CompilerServices;
using System.Text;

Console.WriteLine("Hello, World!");
IConnection conn;
IModel channel;

ConnectionFactory factory = new ConnectionFactory();
factory.HostName = "localhost";
factory.VirtualHost = "/";
factory.Port = 5672;
factory.UserName = "guest";
factory.Password = "guest";
conn = factory.CreateConnection();
channel = conn.CreateModel();

var consumer = new EventingBasicConsumer(channel);
consumer.Received += Consumer_Received;

var consumerTag = channel.BasicConsume(queue: "my.queue1", autoAck: false, consumer: consumer);

Console.WriteLine("Waiting for any message. Press any key to exit " );
Console.ReadKey();

void Consumer_Received(object? sender, BasicDeliverEventArgs e)
{
    var body = e.Body.ToArray();
    var message = Encoding.UTF8.GetString(body);

    channel.BasicNack(deliveryTag: e.DeliveryTag, multiple:false,requeue:true);
    Console.WriteLine("Received message: " + message);
}